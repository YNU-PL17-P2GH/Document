package jp.ac.ynu.pp2.gh.naclo.mapseq;

public class KEY_STATE {	//キーボードの入力状態を表すための定数
	public static final int LEFT = 0;
	public static final int RIGHT = 1;
	public static final int UP = 2;
	public static final int DOWN = 3;
	public static final int Z = 4;
	public static final int X = 5;
	public static final int C = 6;
	public static final int SPACE = 7;
}
