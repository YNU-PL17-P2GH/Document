package jp.ac.ynu.pp2.gh.progdung.map.progobj;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;

import javax.imageio.ImageIO;

import org.jruby.Ruby;
import org.jruby.embed.ScriptingContainer;
import org.jruby.embed.io.ReaderInputStream;
import org.jruby.util.KCode;

import jp.ac.ynu.pp2.gh.naclo.mapseq.ShareInfo;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.MapHandlerBase;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.MapObject;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.MapProgObject;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.RpgMap;
import jp.ac.ynu.pp2.gh.progdung.map.handlers.Hanoito;

public class HanoitoObject3 extends MapProgObject {



	public HanoitoObject3(MapHandlerBase pHandler, int bx, int by, String pObjName, RpgMap pMap) {
		super(pHandler, bx, by, pObjName, pMap);
		try {
			objImg = ImageIO.read(getClass().getClassLoader().getResource("media/map/obj/" + pObjName + ".png"));
		} catch (IOException e) {
			throw new RuntimeException(e);
		}		
//		sourceRuby = "def operate(ido)\n"
//				+ "\t# この下にソースを入力\n"
//				+ "end";
		width=8;
		height=2;
	}

	@Override
	public void draw(ShareInfo sinfo, int map_x, int map_y) {
		// TODO Auto-generated method stub
		for(int i=0;i<3;i++){
			if(Hanoito.tou[i][3]==3){sinfo.g.drawImage(objImg, map_x-i*9*16, map_y+Hanoito.up*16, 256, 64, null);}
		}
		drawFlag = true;
	}

	public void update(ShareInfo sinfo) {
		for(int i=0;i<3;i++){
			if(Hanoito.tou[i][3]==3){getMap().setObj(box_x-i*9, box_y + Hanoito.up1, this);}
		}
		drawFlag = false;
	}

	@Override
	public boolean hitCheck(MapObject obj) {
		return false;
	}
	
	public void runRuby(Ruby ruby) {
		new Thread() {
			public void run() {
				rrwrapper(ruby);
			}
		}.start();
	}
	
	private void rrwrapper(Ruby ruby) {
		ScriptingContainer container = new ScriptingContainer();
		container.setKCode(KCode.UTF8);

		// Issue #2
		InputStream lStream = new ReaderInputStream(new StringReader(sourceRuby), "UTF-8");
//		EmbedEvalUnit lUnit = container.parse(lStream, "temp.rb");
		container.runScriptlet(lStream, "template.rb");
		container.callMethod(ruby.getCurrentContext(), "operate", theOperator);
	}
	
//	public class HanoitoOperator {
//		public void move(int from, int to){
//			if(Hanoito.tou[from][0]==0){Hanoito.tou[to][0]=0;Hanoito.tou[from][0]=-1;}
//			else if(Hanoito.tou[from][1]==1){Hanoito.tou[to][1]=1;Hanoito.tou[from][1]=-1;}
//			else if(Hanoito.tou[from][2]==2){Hanoito.tou[to][2]=2;Hanoito.tou[from][2]=-1;}
//			else if(Hanoito.tou[from][3]==3){Hanoito.tou[to][3]=3;Hanoito.tou[from][3]=-1;}
//			try {
//				Thread.sleep(1000);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
//		}
//	}
}