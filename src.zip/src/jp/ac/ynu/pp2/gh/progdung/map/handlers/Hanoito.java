package jp.ac.ynu.pp2.gh.progdung.map.handlers;

import jp.ac.ynu.pp2.gh.naclo.mapseq.ShareInfo;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.MAP_CONST.DIRECTION;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.MapHandlerBase;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.MapObject;
import jp.ac.ynu.pp2.gh.naclo.mapseq.map.MapPcObject;
import jp.ac.ynu.pp2.gh.progdung.gui.DungeonPlay;
import jp.ac.ynu.pp2.gh.progdung.map.progobj.Array1Object1;
import jp.ac.ynu.pp2.gh.progdung.map.progobj.Array1Object2;

public class Hanoito extends MapHandlerBase{
	
	public static int up=0; 
	public static int up1=0; 
	public static int[][] tou= {{ 0, 1, 2, 3},{-1,-1,-1,-1},{-1,-1,-1,-1}};

	
	public Hanoito(int player_x, int player_y, DIRECTION player_d, DungeonPlay play) {
		super("hanoi", player_x, player_y, player_d, play);
	}

	@Override
	public void onMapLoad() {
		if (!callback.getSaveData().getBoolean("Hanoi003")) {
			showHint("<html>ハノイ塔問題</html>", true);
			callback.getSaveData().setTaken("Hanoi003");
		}
	}

	@Override
	public void playerUpdate() {
		// TODO Auto-generated method stub
	}

	@Override
	public void onPlayerHitTo(MapObject pObject) {
		// TODO Auto-generated method stub
		if (pObject.getObjName().equals("com1")) {
			if (!callback.getSaveData().getBoolean("Hanoi001")) {
				showHint("<html>このパソコンに問題が書いてあります<br>チェックしてみましょう</html>", true);
				callback.getSaveData().setTaken("Hanoi001");
			}
		}
		
		if (pObject.getObjName().equals("com2")) {
			if(!callback.getSaveData().getBoolean("Hanoi002")){
				showHint("<html>これがPCです.<br>ZキーでRubyコードを入力できます.</html>", true);
				callback.getSaveData().setTaken("Hanoi002");
			}
		}
		
	}

	@Override
	public void onPlayerInteract(MapObject pObject) {
		if (pObject instanceof MapPcObject) {
			showCoder((MapPcObject) pObject);
		}
	}

}
