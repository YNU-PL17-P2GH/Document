package jp.ac.ynu.pp2.gh.progdung.gui;

import javax.swing.JPanel;

public class ScriptEditorPanel extends JPanel {

}
